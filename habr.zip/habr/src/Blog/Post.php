<?php

namespace GeekBrains\LevelTwo\Blog;

use GeekBrains\LevelTwo\Person\Person;
use GeekBrains\LevelTwo\Blog\User;
class Post
{
    private int $id;
    private string $title;
    private Person $author;
    private string $text;

    public function __construct(
        int $id,
        string $title,
        Person $author,
        string $text
    )
    {
        $this->id = $id;
        $this->title = $title;
        $this->author = $author;
        $this->text = $text;
    }

    public function __toString()
    {
        return $this->author .'<<< ' . $this->title . ' >>> ' . $this->text  . PHP_EOL;
    }
}