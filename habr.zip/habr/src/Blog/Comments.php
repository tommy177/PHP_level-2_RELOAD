<?php

namespace GeekBrains\LevelTwo\Blog;



use GeekBrains\LevelTwo\Blog\Post;
use GeekBrains\LevelTwo\Blog\User;
use GeekBrains\LevelTwo\Person\Person;

class comments
{
    public function __construct
    (
        private int    $id,
        private Post   $id_post,
        private Person   $id_user,
        private string $description,
    )
    {
        $this->id = $id;
        $this->id_post = $id_post;
        $this->id_user = $id_user;
        $this->description = $description;
    }

    public function __toString(): string
    {
        return 'Коментарий от ' . $this->id_user . $this->description;
    }

}