<?php
use GeekBrains\LevelTwo\Blog\User;
use GeekBrains\LevelTwo\Person\{Name, Person};
use GeekBrains\LevelTwo\Blog\Post;
use GeekBrains\LevelTwo\Blog\Comments;
use GeekBrains\LevelTwo\Blog\Repositories\InMemoryUsersRepository;
use GeekBrains\LevelTwo\Blog\Exceptions\UserNotFoundException;

include __DIR__ . "/vendor/autoload.php";

//var_dump($argv);
$faker = Faker\Factory::create('ru_RU');
$firstname = $faker->firstName;
$lastname = $faker->lastName;
$title = $faker->country;
$description = $faker->phoneNumber();

$i = 1;


//echo $faker->name() . PHP_EOL;

$text =  $faker->realText(rand(50, 70));

$name = new Name($firstname,$lastname);
$person = new Person($name, new DateTimeImmutable());
$user = new User(1, $name, $lastname);
$post = new Post(1, $title, $person, $text);
$comment = new Comments(1, $post, $person,$description);


//echo $user . PHP_EOL;
//echo $post;
//echo $comment;
foreach ($argv as $arg)
{
    if($arg == 'user')
    {
        echo $user;
    }elseif($arg == 'post'){
        echo $post;
    }elseif ($arg == 'comment'){
        echo $comment;
    }elseif($arg == 'cli.php'){
        continue;
    }
}










//
//$name = new Name('Peter', 'Sidorov');
//
//$user = new User(1, $name, "Admin");
//echo $user;
//
//
//$name = new Name('Peter', 'Sidorov');
//$person = new Person($name, new DateTimeImmutable());
//
//
//$post = new Post(
//    1,
//    $person,
//    'Всем привет!'
//);
//
//echo $post;
//
//$name2 = new Name('Иван', 'Таранов');
//$user2 = new User(2, $name2, "User");
//$userRepository = new InMemoryUsersRepository();
//try {
//$userRepository->save($user);
//$userRepository->save($user2);
//
//
//    echo $userRepository->get(1);
//    echo $userRepository->get(2);
//    echo $userRepository->get(3);
//} catch (UserNotFoundException | Exception $e) {
//    echo $e->getMessage();
//}